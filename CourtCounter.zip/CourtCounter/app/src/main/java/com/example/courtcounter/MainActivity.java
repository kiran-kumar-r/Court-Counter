package com.example.courtcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayForTeamA( 0 );
    }

    int scoreTeamA = 0, scoreTeamB = 0 ;

    public void three_button(View view) {
        scoreTeamA += 3 ;
        displayForTeamA(scoreTeamA);
    }
    public void two_button(View view) {
        scoreTeamA += 2 ;
        displayForTeamA(scoreTeamA);
    }
    public void one_button(View view) {
        scoreTeamA += 1 ;
        displayForTeamA(scoreTeamA);
    }
    public void three_button_b(View view) {
        scoreTeamB += 3 ;
        displayForTeamB(scoreTeamB);
    }
    public void two_button_b(View view) {
        scoreTeamB += 2 ;
        displayForTeamB(scoreTeamB);
    }
    public void one_button_b(View view) {
        scoreTeamB += 1 ;
        displayForTeamB(scoreTeamB);
    }

    public void reset( View view ) {
        displayForTeamA(0);
        displayForTeamB(0);
    }

    public void displayForTeamA( int score_a ) {
        TextView scoreViewA = (TextView) findViewById(R.id.team_a_score) ;
        scoreViewA.setText( String.valueOf(score_a) );
    }

    public void displayForTeamB( int score_b ) {
        TextView scoreViewB = (TextView) findViewById(R.id.team_b_score);
        scoreViewB.setText( String.valueOf( score_b ) );
    }

}
